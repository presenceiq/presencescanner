import { isSiteDisabled, disabledResponse } from './_killswitch.js';
import { spend, refused } from './_budget.js';

// How many candidates to pull full details for when a phone number
// maps to more than one business. Keeps API cost/latency bounded.
const MAX_CANDIDATES = 5;

const DETAIL_FIELDS =
  'name,rating,user_ratings_total,formatted_address,formatted_phone_number,website,opening_hours,photos,business_status,types';

// Normalize a business name for loose matching (lowercase, strip anything
// that isn't a letter or number, collapse spaces).
function normalizeName(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

// Score how well a candidate name matches the name the user is scanning.
// Higher = better. 0 = no meaningful overlap.
function nameMatchScore(candidateName, wantedName) {
  const c = normalizeName(candidateName);
  const w = normalizeName(wantedName);
  if (!c || !w) return 0;
  if (c === w) return 100;                 // exact
  if (c.includes(w) || w.includes(c)) return 80; // one contains the other
  // token overlap
  const ct = new Set(c.split(' '));
  const wt = w.split(' ');
  let hits = 0;
  for (const t of wt) if (t && ct.has(t)) hits++;
  return hits * 10;
}

// Normalize a website to a bare host for loose matching (drop scheme, www, path).
function normalizeSite(s) {
  return String(s || '')
    .toLowerCase().trim()
    .replace(/^https?:\/\//, '')
    .replace(/^www\./, '')
    .replace(/\/.*$/, '')
    .trim();
}

// Score how well a candidate's website matches the one the owner typed.
// Same 0-100 scale as nameMatchScore, so name and website carry EQUAL weight.
function siteMatchScore(candidateSite, wantedSite) {
  const c = normalizeSite(candidateSite);
  const w = normalizeSite(wantedSite);
  if (!c || !w) return 0;
  if (c === w) return 100;                        // exact host match
  if (c.includes(w) || w.includes(c)) return 60;  // one contains the other
  return 0;
}

// Fetch full details for one place_id. Returns { result, status, errorMessage }
// so the caller can distinguish a genuine miss from a Google-side failure.
async function fetchDetails(placeId, apiKey) {
  const url =
    'https://maps.googleapis.com/maps/api/place/details/json' +
    '?place_id=' + encodeURIComponent(placeId) +
    '&fields=' + DETAIL_FIELDS +
    '&key=' + apiKey;
  const r = await fetch(url);
  const j = await r.json();
  return { result: j.result || null, status: j.status || null, errorMessage: j.error_message || null };
}

// SECOND CHANCE FOR HIDDEN-ADDRESS BUSINESSES (8 Oct 2026).
// Cleaners, pool services, pressure washers and other businesses that hide
// their address are left out of the older Google lookup above, even by phone.
// Google's newer search includes them only when asked to
// (includePureServiceAreaBusinesses, added by Google Nov 2024). We use it only
// when the older lookup finds nothing, and we accept a result ONLY if its phone
// number matches the one the owner typed, so a same-name business elsewhere is
// never picked. One search returns everything the report needs.
const SAB_FIELDS = [
  'places.id', 'places.displayName', 'places.formattedAddress', 'places.nationalPhoneNumber',
  'places.internationalPhoneNumber', 'places.websiteUri', 'places.rating', 'places.userRatingCount',
  'places.regularOpeningHours', 'places.photos', 'places.businessStatus', 'places.types',
  'places.pureServiceAreaBusiness',
].join(',');

async function sabSearch(textQuery, apiKey) {
  const r = await fetch('https://places.googleapis.com/v1/places:searchText', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': apiKey, 'X-Goog-FieldMask': SAB_FIELDS },
    body: JSON.stringify({ textQuery: textQuery, includePureServiceAreaBusinesses: true, regionCode: 'US', pageSize: 20 }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    console.error('SAB SEARCH ' + r.status + ' ' + JSON.stringify(j).slice(0, 300));
    return [];
  }
  return Array.isArray(j.places) ? j.places : [];
}

function sabPhoneDigits(p) {
  let d = String((p && (p.nationalPhoneNumber || p.internationalPhoneNumber)) || '').replace(/\D/g, '');
  if (d.length === 11 && d.startsWith('1')) d = d.slice(1);
  return d;
}

function shapeSab(p) {
  const hours = p.regularOpeningHours && Array.isArray(p.regularOpeningHours.weekdayDescriptions)
    ? p.regularOpeningHours.weekdayDescriptions.slice(0, 7) : [];
  return {
    found: true,
    placeId: p.id,
    name: (p.displayName && p.displayName.text) || null,
    rating: typeof p.rating === 'number' ? p.rating : null,
    reviewCount: typeof p.userRatingCount === 'number' ? p.userRatingCount : 0,
    address: p.formattedAddress || null,
    phone: p.nationalPhoneNumber || p.internationalPhoneNumber || null,
    website: p.websiteUri || null,
    hasHours: !!p.regularOpeningHours,
    isOpen: null,
    hours: hours,
    photoCount: Array.isArray(p.photos) ? p.photos.length : 0,
    businessStatus: p.businessStatus || null,
    types: Array.isArray(p.types) ? p.types : [],
    // Found by the hidden-address search. The Google Maps rank check can't see
    // these businesses, so the scanner skips that check for them.
    serviceArea: true,
    matchCount: 1,
  };
}

async function sabLookup(req, digits, name, city, website, apiKey) {
  const ok = await spend(req, 'sab');
  if (!ok.ok) return null;
  const queries = [];
  if (name && String(name).trim()) queries.push(String(name).trim() + (city ? ' ' + String(city).trim() : ''));
  queries.push('(' + digits.slice(0, 3) + ') ' + digits.slice(3, 6) + '-' + digits.slice(6));
  for (const q of queries) {
    const places = await sabSearch(q, apiKey);
    const hits = places.filter((p) => sabPhoneDigits(p) === digits);
    if (hits.length) {
      hits.sort((a, b) =>
        (nameMatchScore(b.displayName && b.displayName.text, name) + siteMatchScore(b.websiteUri, website)) -
        (nameMatchScore(a.displayName && a.displayName.text, name) + siteMatchScore(a.websiteUri, website)));
      const out = shapeSab(hits[0]);
      out.matchCount = hits.length;
      out.sharedPhoneNumber = hits.length > 1;
      return out;
    }
  }
  return null;
}

// Shape a Google details result into the object the rest of the app expects.
function shape(placeId, d) {
  return {
    found: true,
    placeId: placeId,
    name: d.name || null,
    rating: d.rating || null,
    reviewCount: d.user_ratings_total || 0,
    address: d.formatted_address || null,
    phone: d.formatted_phone_number || null,
    website: d.website || null,
    hasHours: !!(d.opening_hours),
    isOpen: d.opening_hours?.open_now ?? null,
    hours: Array.isArray(d.opening_hours?.weekday_text) ? d.opening_hours.weekday_text.slice(0, 7) : [],
    photoCount: d.photos?.length || 0,
    businessStatus: d.business_status || null,
    types: d.types || [],
  };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  // KILL SWITCH — if SITE_DISABLED=true in Vercel env vars, return immediately.
  if (isSiteDisabled()) return disabledResponse(res);
  // SPENDING GUARD: caps paid Google lookups per visitor and per day. (6 Oct 2026)
  { const ok = await spend(req, 'google'); if (!ok.ok) return refused(res, ok.message); }

  try {
    // `name` is OPTIONAL. When the scan sends it, we use it to pick the
    // right business if the phone number maps to more than one.
    const { phone, name, website, city } = req.body || {};
    const apiKey = process.env.GOOGLE_PLACES_KEY;

    if (!phone || !String(phone).trim()) {
      return res.status(200).json({ found: false, message: 'No phone number provided' });
    }

    // ---------------------------------------------------------------
    // Step 1: normalize the phone into E.164 (+1XXXXXXXXXX), US assumed.
    // ---------------------------------------------------------------
    let digits = String(phone).replace(/\D/g, '');
    if (digits.length === 11 && digits.startsWith('1')) digits = digits.slice(1);
    if (digits.length !== 10) {
      return res.status(200).json({ found: false, message: 'Phone number not in a recognized format' });
    }
    const e164 = '+1' + digits;

    // ---------------------------------------------------------------
    // Step 2: ask Google "Find Place From Text" by phone number.
    // NOTE: one phone number can map to MULTIPLE businesses (e.g. an
    // owner who runs several businesses off one line). We must NOT
    // assume a single result here.
    // ---------------------------------------------------------------
    const findUrl =
      'https://maps.googleapis.com/maps/api/place/findplacefromtext/json' +
      '?input=' + encodeURIComponent(e164) +
      '&inputtype=phonenumber' +
      '&fields=place_id' +
      '&key=' + apiKey;

    const findRes = await fetch(findUrl);
    const findData = await findRes.json();

    // Only ZERO_RESULTS means "no business with that phone." Any other non-OK
    // status is an upstream failure and must not be reported as "not found."
    if (findData.status && findData.status !== 'OK' && findData.status !== 'ZERO_RESULTS') {
      return res.status(502).json({
        error: true,
        upstream: 'google-places-findplacefromtext',
        googleStatus: findData.status,
        googleErrorMessage: findData.error_message || null,
        message: `Google findplacefromtext returned ${findData.status}`,
      });
    }

    if (!findData.candidates || findData.candidates.length === 0) {
      try {
        const sab = await sabLookup(req, digits, name, city, website, apiKey);
        if (sab) return res.status(200).json(sab);
      } catch (e) { console.error('SAB LOOKUP ERROR ' + String(e).slice(0, 200)); }
      return res.status(200).json({ found: false, message: 'No Google business found for that phone number' });
    }

    // ---------------------------------------------------------------
    // Step 3: pull full details for EVERY candidate (capped), instead of
    // blindly taking candidates[0]. This is the core of the shared-number fix.
    // ---------------------------------------------------------------
    const ids = findData.candidates
      .map((c) => c.place_id)
      .filter(Boolean)
      .slice(0, MAX_CANDIDATES);

    const detailed = [];
    let lastDetailError = null;
    for (const id of ids) {
      const { result, status, errorMessage } = await fetchDetails(id, apiKey);
      if (status && status !== 'OK') {
        lastDetailError = { googleStatus: status, googleErrorMessage: errorMessage };
        continue;
      }
      if (result) detailed.push({ placeId: id, d: result });
    }

    if (detailed.length === 0) {
      if (lastDetailError) {
        return res.status(502).json({
          error: true,
          upstream: 'google-places-details',
          googleStatus: lastDetailError.googleStatus,
          googleErrorMessage: lastDetailError.googleErrorMessage,
          message: `Google Places details returned ${lastDetailError.googleStatus} for all candidates`,
        });
      }
      return res.status(200).json({ found: false, message: 'Found a match but could not load its details' });
    }

    // Split operational vs. permanently-closed. A closed listing should
    // never be handed back as the business unless it's the ONLY thing there.
    const isClosed = (d) => (d.business_status && d.business_status !== 'OPERATIONAL');
    const operational = detailed.filter((x) => !isClosed(x.d));
    const pool = operational.length ? operational : detailed;

    // ---------------------------------------------------------------
    // Step 4: choose the PRIMARY result when a phone maps to several
    // businesses. Name and website are weighted EQUALLY (same 0-100 scale),
    // so either one can pull the right business to the top. Phone already got
    // us into this pool, so it isn't scored again here.
    //  - If neither name nor website was passed, take the first operational one.
    // ---------------------------------------------------------------
    let primary = pool[0];
    const haveTiebreak = (name && String(name).trim()) || (website && String(website).trim());
    if (haveTiebreak && pool.length > 1) {
      const scoreOf = (cand) =>
        nameMatchScore(cand.d.name, name) + siteMatchScore(cand.d.website, website);
      let best = pool[0];
      let bestScore = scoreOf(pool[0]);
      for (let i = 1; i < pool.length; i++) {
        const s = scoreOf(pool[i]);
        if (s > bestScore) { best = pool[i]; bestScore = s; }
      }
      primary = best;
    }

    // Build the response: SAME shape as before for the primary (so the
    // existing front end keeps working untouched), plus extra fields for
    // the "which of these is yours?" picker and the shared-number finding.
    const out = shape(primary.placeId, primary.d);

    out.matchCount = detailed.length;
    out.sharedPhoneNumber = detailed.length > 1; // the conflation finding flag
    out.candidates = detailed.map((x) => ({
      placeId: x.placeId,
      name: x.d.name || null,
      address: x.d.formatted_address || null,
      businessStatus: x.d.business_status || null,
      isClosed: isClosed(x.d),
    }));

    return res.status(200).json(out);

  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
